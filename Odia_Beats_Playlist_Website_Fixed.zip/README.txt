ODIA BEATS PLAYLIST WEBSITE

1. Open index.html in Chrome.
2. Tap "ନିଜର MP3 ଗୀତ ଯୋଡ଼ନ୍ତୁ" and select your legally obtained Odia audio files.
3. Use Play/Pause, Next/Previous and the search box.

The site is mobile-friendly and does not include copyrighted music files.
